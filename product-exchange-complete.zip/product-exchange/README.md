# Local Product Exchange – Buy & Sell Marketplace

A locally hosted marketplace for participants to buy, sell, negotiate, and exchange product variants using virtual wallet balances and JSON-file storage.

## Technology
- Node.js 18+ and Express
- HTML5, CSS3, vanilla JavaScript and Fetch API
- JSON files for persistent application data
- bcryptjs password hashing and express-session authentication

## Requirements
- Ubuntu 22.04 (also works on other platforms with Node.js 18+)
- Node.js 18 or newer and npm
- Google Chrome or another modern browser

## Quick start (Ubuntu 22.04)

1. Extract the ZIP archive.
2. Open a terminal in the extracted `product-exchange` directory.
3. Install Node.js 18+ if it is not already installed. One option is NodeSource:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```
4. Install dependencies:
   ```bash
   npm install
   ```
5. Create your environment file:
   ```bash
   cp .env.example .env
   ```
   Change `SESSION_SECRET` to a long random value before using the app beyond a local demo.
6. Start the server:
   ```bash
   npm start
   ```
7. Open **http://localhost:3000** in Google Chrome.

The application automatically creates missing JSON data files and initializes demo users, products, wallets, portfolios, and sample orders on its first run.

## Demo accounts

| Username | Password | Initial wallet |
|---|---|---:|
| trader1 | password123 | ₹50,000 |
| trader2 | password123 | ₹50,000 |
| trader3 | password123 | ₹50,000 |

You can also register a new participant. New accounts start with a ₹50,000 virtual wallet.

## Features
- Participant registration, login, logout and protected API routes
- Dashboard with wallet, portfolio, orders, offers and recent trades
- Product catalogue and independently tradable variants
- Buy and sell orders with backend-side wallet/stock reservation
- Cancellation releases the corresponding remaining reservation
- Offers, counteroffers, rejection and acceptance
- Trade execution updates both wallets, both portfolios, order remainder, transaction history and ledgers
- Partial fills leave the remaining order quantity available
- Wallet ledger, portfolio ledger, notifications and transaction history
- Responsive browser interface

## Project structure

```text
product-exchange/
├── server.js
├── package.json
├── .env.example
├── README.md
├── data/
│   ├── participants.json
│   ├── products.json
│   ├── product_variants.json
│   ├── wallets.json
│   ├── portfolios.json
│   ├── buy_orders.json
│   ├── sell_orders.json
│   ├── offers.json
│   ├── transactions.json
│   ├── wallet_ledger.json
│   ├── portfolio_ledger.json
│   └── notifications.json
└── public/
    ├── index.html
    ├── css/style.css
    └── js/app.js
```

## JSON data files

All persistent application records are stored under `data/`. The server creates absent files on startup. Passwords are stored as bcrypt hashes, never as plaintext. Do not edit the files while the server is running. Back up the complete `data/` directory before making manual changes.

To reset the demo data, stop the server, delete the JSON files inside `data/`, and restart the application. This recreates the demo accounts and sample records. **This permanently removes locally stored activity.**

## API overview

All business operations are handled by the backend. Authenticated routes use the session cookie.

| Area | Routes |
|---|---|
| Authentication | `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me` |
| Dashboard | `GET /api/dashboard` |
| Products | `GET /api/products`, `GET /api/products/:id/variants` |
| Orders | `GET /api/orders`, `GET /api/orders/mine`, `POST /api/orders`, `POST /api/orders/:id/cancel` |
| Offers | `GET /api/offers`, `POST /api/offers`, `POST /api/offers/:id/accept`, `/reject`, `/counter` |
| Wallet | `GET /api/wallet`, `GET /api/wallet/ledger` |
| Portfolio | `GET /api/portfolio` |
| Transactions | `GET /api/transactions`, `GET /api/transactions/:id` |
| Notifications | `GET /api/notifications`, `POST /api/notifications/:id/read` |

## Important implementation notes and limitations

- This project is intended for local learning, demonstration and small-scale use. It uses virtual money only; there is no payment gateway.
- JSON storage is not a production database. The server serializes file writes and writes each file through a temporary file followed by rename. Multi-file trade updates are serialized in one process, but this is not a crash-proof database transaction or a cross-process lock.
- Run a **single Node.js server process**. Do not use clustering, multiple instances, or shared network storage with this JSON implementation. A sudden power loss between separate file renames can leave related files out of sync.
- For a public or production marketplace, use a transactional database such as SQLite or PostgreSQL, durable transaction boundaries, a persistent session store, HTTPS, CSRF protection, rate limiting, audit logging, and operational backups.
- Sessions use Express's in-memory session store. Logging in again may be required after a server restart.
- The sample application uses demo credentials and a development session secret by default. Change the secret and credentials before exposing the app to any network.
- Wallet/stock checks and transaction updates are performed on the server. Never expose this demo to the public internet as-is.

## Troubleshooting

**`node: command not found`** – Install Node.js 18 or newer and reopen the terminal.

**Port 3000 is already in use** – Set another port in `.env`, for example `PORT=3001`, then restart and open `http://localhost:3001`.

**Login does not work** – Use one of the demo credentials exactly, or remove the data JSON files while the server is stopped to reset the demo.

**Blank or stale page** – Refresh Chrome. Check the terminal running `npm start` for server errors.

## Stop the application

Press `Ctrl+C` in the terminal where the server is running.
